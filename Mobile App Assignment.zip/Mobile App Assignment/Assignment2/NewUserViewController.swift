//
//  NewUserViewController.swift
//  Assignment2
//
//  Created by Test on 27/10/18.
//  Copyright © 2018 Test. All rights reserved.
//

import UIKit

class NewUserViewController:UIViewController,UIPickerViewDelegate,
UIPickerViewDataSource {
   
    @IBOutlet weak var ID_input: UITextField!
    @IBOutlet weak var ID: UILabel!
    @IBOutlet weak var LnameInput: UITextField!
    @IBOutlet weak var Register: UIButton!
    @IBOutlet weak var BackButton: UIButton!
    
    @IBOutlet weak var picker: UIPickerView!
    @IBOutlet weak var coarseInput: UIPickerView!
    @IBOutlet weak var addressInput: UITextField!
    @IBOutlet weak var genderInput: UISegmentedControl!
    @IBOutlet weak var ageInput: UIStepper!
    @IBOutlet weak var FnameInput: UITextField!
    @IBOutlet weak var Course: UILabel!
    @IBOutlet weak var Address: UILabel!
    @IBOutlet weak var Age: UILabel!
    @IBOutlet weak var Gender: UILabel!
    @IBOutlet weak var LastName: UILabel!
    @IBOutlet weak var FirstName: UILabel!
    
    
    var pickerData = ["Mobile Application Development", "Programming Fundamentals", "Computer Networking", "Database and Design"];
    @IBAction func stepperchanged(_ sender: UIStepper) {
        let step = Int(ageInput.value) // using an integer variable
        Age.text = String(step)
        // label1.text = Int(stepper.value).description
        // another way without using any integer variable
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.picker.dataSource = self
        self.picker.delegate = self
        ageInput.wraps = true
        ageInput.autorepeat = true
        ageInput.maximumValue = 10        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // The number of columns of data
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    // The number of rows of data
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent
        component: Int) -> Int {
        return pickerData.count
    }
    // The data to return for the row and component that's being passed in
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int,
                    forComponent component: Int) -> String? {
        return pickerData[row]
    }

    @IBAction func saveStudent(_ sender: Any) {
        // get the AppDelegate object
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        // call function storePersonInfo in AppDelegate
         var genderName: Any!
  /*      if self.genderInput.selectedSegmentIndex == 0 {
            genderName: String = "male";
           // label1.text = “male”
        }
        else {
            genderName: String = "female";
            
        } */
        
        //, gender:Int(genderInput.text!)!, age:Int(ageInput.text!), course: coarseInput.text!, address: addressInput.text!
        appDelegate.storeStudentInfo(id:
            Int(ID_input.text!)!, firstName: FnameInput.text!, lastName: LnameInput.text!)    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
